# Sleeping-Barber-Problem-on-kernel
Using pThreads library to solve Sleeping barber Synchronization Problem


```
$ sudo apt-get update
$ sudo apt-get upgrade
```
take administrative rights

```
$ sudo -s
$ apt-get install gcc
```

Downloading python 

```
apt-get install python-pip python-dev libffi-dev libssl-dev libxml2-dev libxslt1-dev libjpeg8-dev zlib1g-dev
apt-get install libncursesw5-dev
```
